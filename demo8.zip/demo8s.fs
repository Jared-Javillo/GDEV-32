/******************************************************************************
 * This fragment shader does nothing (i.e., the rasterizer will simply write
 * the depth value to the framebuffer).
 *
 * Happy hacking! - eric
 *****************************************************************************/

#version 330 core

void main()
{
}
